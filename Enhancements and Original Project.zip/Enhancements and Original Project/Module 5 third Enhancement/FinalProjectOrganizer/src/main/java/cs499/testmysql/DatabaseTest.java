package cs499.testmysql;

import cs499.database.DatabaseConnection;
import cs499.database.AppointmentDAO;
import cs499.database.TaskDAO;
import cs499.appointment.Appointment;
import cs499.task.Task;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Random;

public class DatabaseTest {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            AppointmentDAO appointmentDAO = new AppointmentDAO(connection);
            TaskDAO taskDAO = new TaskDAO(connection);
            Random random = new Random();

            // Insert Random Appointment
            String appointmentId = "A" + random.nextInt(1000);
            Date appointmentDate = new Date(System.currentTimeMillis() + (random.nextInt(10) * 86400000L)); // Random date within 10 days
            String description = "Test Appointment " + random.nextInt(100);
            Appointment appointment = new Appointment(appointmentId, appointmentDate, description);
            appointmentDAO.createAppointment(appointment);
            System.out.println("Inserted Appointment: " + appointmentId);

            // Insert Random Task
            String taskId = "T" + random.nextInt(1000);
            String taskName = "Test Task " + random.nextInt(100);
            String taskDescription = "This is a randomly generated task.";
            Task task = new Task(taskId, taskName, taskDescription);
            taskDAO.addTask(task);
            System.out.println("Inserted Task: " + taskId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}