package cs499.Task_Service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        boolean result = taskService.addTask("1", "Task 1", "Description for task 1");
        assertTrue(result);
        assertTrue(taskService.getTask("1").isPresent());
    }

    @Test
    public void testAddDuplicateTask() {
        taskService.addTask("1", "Task 1", "Description for task 1");
        boolean result = taskService.addTask("1", "Task 1 Duplicate", "Duplicate task");
        assertFalse(result);
    }

    @Test
    public void testDeleteTask() {
        taskService.addTask("1", "Task 1", "Description for task 1");
        boolean result = taskService.deleteTask("1");
        assertTrue(result);
        assertFalse(taskService.getTask("1").isPresent());
    }

    @Test
    public void testDeleteNonExistentTask() {
        boolean result = taskService.deleteTask("999");
        assertFalse(result);
    }

    @Test
    public void testUpdateTaskName() {
        taskService.addTask("1", "Task 1", "Description for task 1");
        boolean result = taskService.updateTaskName("1", "Updated Task 1");
        assertTrue(result);
        assertTrue(taskService.getTask("1").isPresent());
        assertEquals("Updated Task 1", taskService.getTask("1").get().getName());
    }

    @Test
    public void testUpdateNonExistentTaskName() {
        boolean result = taskService.updateTaskName("999", "Updated Task");
        assertFalse(result);
    }

    @Test
    public void testUpdateTaskDescription() {
        taskService.addTask("1", "Task 1", "Description for task 1");
        boolean result = taskService.updateTaskDescription("1", "Updated Description");
        assertTrue(result);
        assertTrue(taskService.getTask("1").isPresent());
        assertEquals("Updated Description", taskService.getTask("1").get().getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskDescription() {
        boolean result = taskService.updateTaskDescription("999", "Updated Description");
        assertFalse(result);
    }
}