package cs499.Task_Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** The TaskService class provides functionality to add, delete,
 update, and retrieve a collection of tasks by their ID.
 */
public class TaskService {
    private final Map<String, Task> tasks;

    public TaskService() {
        tasks = new HashMap<>();
    }

    /** Adds a new task.
     @param taskId      The task ID.
     @param name        The task name.
     @param description The task description.
     @return true if the task is added successfully, false if the task ID already exists.
     */
    public boolean addTask(String taskId, String name, String description) {
        if (tasks.containsKey(taskId)) {
            return false;
        }
        Task newTask = new Task(taskId, name, description);
        tasks.put(taskId, newTask);
        return true;
    }

    /** Deletes a task.
     @param taskId The task ID.
     @return true if the task was deleted, false if the task ID was not found.
     */
    public boolean deleteTask(String taskId) {
        return tasks.remove(taskId) != null; // Returns true if task was found and removed
    }

    /** Updates the name of an existing task.
     @param taskId    The task ID.
     @param newName   The new task name.
     @return true if the task was updated, false if the task was not found.
     */
    public boolean updateTaskName(String taskId, String newName) {
        return updateTaskAttribute(taskId, task -> task.setName(newName));
    }

    /**
     * Updates the description of a task.
     @param taskId          The task ID.
     @param newDescription  The new task description.
     @return true if the task was updated, false if the task was not found.
     */
    public boolean updateTaskDescription(String taskId, String newDescription) {
        return updateTaskAttribute(taskId, task -> task.setDescription(newDescription));
    }

    /**
     * Retrieves a task by its unique ID.
     @param taskId The task ID.
     @return an Optional containing the task if found, or an empty Optional if not found.
     */
    public Optional<Task> getTask(String taskId) {
        return Optional.ofNullable(tasks.get(taskId)); // Returning Optional
    }

    // Updates any task attribute
    private boolean updateTaskAttribute(String taskId, TaskUpdater updater) {
        Task task = tasks.get(taskId);
        if (task != null) {
            updater.update(task);
            return true;
        }
        return false;
    }

    // Interface for updating task
    @FunctionalInterface
    private interface TaskUpdater {
        void update(Task task);
    }
}