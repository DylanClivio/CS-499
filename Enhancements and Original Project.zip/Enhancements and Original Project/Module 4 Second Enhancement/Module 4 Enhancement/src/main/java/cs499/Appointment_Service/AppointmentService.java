package cs499.Appointment_Service;

import java.util.*;

/** The AppointmentService class allows the user to manage appointments
 * with adding, deleting, and retrieving appointments by their ID.
 */

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public boolean addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment with this ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
        return true;
    }

    public void addAppointments(List<Appointment> newAppointments) {
        for (Appointment appointment : newAppointments) {
            addAppointment(appointment);
        }
    }

    public boolean deleteAppointment(String appointmentId) {
        return appointments.remove(appointmentId) != null;
    }

    public void deleteAppointments(List<String> appointmentIds) {
        for (String id : appointmentIds) {
            appointments.remove(id);
        }
    }

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(appointments.values());
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}