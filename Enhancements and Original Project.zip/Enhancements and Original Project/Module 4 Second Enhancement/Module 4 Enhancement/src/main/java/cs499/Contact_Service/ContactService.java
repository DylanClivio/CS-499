package cs499.Contact_Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/** The ContactService class allows the user to manage contacts by
 * adding, deleting, updating, and retrieving them by their ID.
 */
public class ContactService {
    private Map<String, Contact> contacts = new ConcurrentHashMap<>(); // Thread-safe

    // Add new contact
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new DuplicateContactIdException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete contact by ID
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new ContactNotFoundException("Contact not found");
        }
        contacts.remove(contactId);
    }

    // Update contact's first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new ContactNotFoundException("Contact not found");
        }
        contact.setFirstName(firstName);
    }

    // Update contact's last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new ContactNotFoundException("Contact not found");
        }
        contact.setLastName(lastName);
    }

    // Update contact's phone number
    public void updatePhone(String contactId, String phone) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new ContactNotFoundException("Contact not found");
        }
        contact.setPhone(phone);
    }

    // Update contact's address
    public void updateAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new ContactNotFoundException("Contact not found");
        }
        contact.setAddress(address);
    }

    // Get a contact by its unique ID
    public Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new ContactNotFoundException("Contact not found");
        }
        return contact;
    }

    // Batch update contacts
    public void batchUpdate(Map<String, Contact> updates) {
        for (Map.Entry<String, Contact> entry : updates.entrySet()) {
            String contactId = entry.getKey();
            Contact updatedContact = entry.getValue();

            Contact existingContact = contacts.get(contactId);
            if (existingContact != null) {
                existingContact.setFirstName(updatedContact.getFirstName());
                existingContact.setLastName(updatedContact.getLastName());
                existingContact.setPhone(updatedContact.getPhone());
                existingContact.setAddress(updatedContact.getAddress());
            } else {
                throw new ContactNotFoundException("Contact with ID " + contactId + " not found for update.");
            }
        }
    }

    // Exception for repeated contact IDs
    public static class DuplicateContactIdException extends RuntimeException {
        public DuplicateContactIdException(String message) {
            super(message);
        }
    }

    // Exception for contact not found
    public static class ContactNotFoundException extends RuntimeException {
        public ContactNotFoundException(String message) {
            super(message);
        }
    }
}